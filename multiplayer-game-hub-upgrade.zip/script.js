/* This compatibility entry points to the full Next.js application. It does not simulate multiplayer. */
(() => {
  const target = document.getElementById('enter');
  if (target) target.href = '/' + window.location.search;
  if (window.location.pathname === '/index.html' && /^https?:$/.test(window.location.protocol)) {
    window.location.replace('/' + window.location.search);
  }
})();
