/* GAMEHUB: one authoritative Node process, one public HTTP(S) origin. */
require('dotenv').config({ quiet: true });
require('tsx/cjs');
const express = require('express');
const { createServer } = require('node:http');
const { randomInt, randomUUID, createHash } = require('node:crypto');
const { Server } = require('socket.io');
const { eq, gt, and, sql, desc } = require('drizzle-orm');
const { db } = require('./src/db/index.ts');
const { gameRooms, gameMatches } = require('./src/db/schema.ts');
const { createGame, applyAction, tickGame, publicState, botAction, resumeClock } = require('./src/lib/game-engine.ts');
const { GAMES, TURN_GAMES, BOT_GAMES } = require('./src/lib/catalog.ts');
const { AVATARS } = require('./src/lib/types.ts');
const TTL = 24 * 60 * 60 * 1000;
const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

function createRealtimeServer(httpServer) {
  if (httpServer.gamehubIO) return httpServer.gamehubIO;
  const allowed = [process.env.APP_URL, process.env.RENDER_EXTERNAL_URL, ...(process.env.ALLOWED_ORIGINS || '').split(',')].filter(Boolean).map(v => v.replace(/\/$/, ''));
  const io = new Server(httpServer, {
    cors: { origin: (origin, callback) => callback(null, !origin || !allowed.length || allowed.includes(origin)), methods: ['GET', 'POST'] },
    connectionStateRecovery: { maxDisconnectionDuration: 120000, skipMiddlewares: false },
    addTrailingSlash: false,
    maxHttpBufferSize: 16000, pingInterval: 8000, pingTimeout: 7000,
    allowRequest: (req, callback) => {
      const origin = req.headers.origin;
      const host = req.headers['x-forwarded-host'] || req.headers.host;
      callback(null, !origin || !allowed.length || allowed.includes(origin) || origin === `https://${host}` || (process.env.NODE_ENV !== 'production' && origin === `http://${host}`));
    },
  });
  httpServer.gamehubIO = io;
  const rooms = new Map(), saves = new Map(), loads = new Map(), recorded = new Set(), creationLimits = new Map();
  let lastPrune = Date.now();

  function message(room, text) { room.messages.push({ id: randomUUID(), playerId: 'system', name: 'GameHub', text, at: Date.now(), system: true }); room.messages = room.messages.slice(-80); }
  function save(room) {
    const snapshot = structuredClone(room);
    const pending = (saves.get(room.code) || Promise.resolve()).catch(() => {}).then(() => db.insert(gameRooms).values({ code: room.code, snapshot, updatedAt: new Date(snapshot.updatedAt), expiresAt: new Date(Date.now() + TTL) }).onConflictDoUpdate({ target: gameRooms.code, set: { snapshot, updatedAt: new Date(snapshot.updatedAt), expiresAt: new Date(Date.now() + TTL) } }));
    saves.set(room.code, pending);
    pending.catch(error => console.error('Room persistence failed:', error.message));
    return pending;
  }
  function snapshot(room, viewer) { return { ...room, state: room.state ? publicState(room.state, viewer) : null }; }
  function publish(room, persist = true) {
    room.updatedAt = Date.now();
    for (const sid of io.sockets.adapter.rooms.get(room.code) || []) { const socket = io.sockets.sockets.get(sid); if (socket) socket.emit('room:state', snapshot(room, socket.data.playerId)); }
    if (persist) save(room);
    if (room.state?.status === 'finished') {
      room.status = 'finished';
      const id = `${room.code}-${room.matchNo}-${room.createdAt}`;
      if (!recorded.has(id)) {
        recorded.add(id);
        db.insert(gameMatches).values({ id, roomCode: room.code, game: room.selectedGame, mode: room.mode, players: room.players.map(({id,name,avatar}) => ({id,name,avatar})), scores: room.state.scores, winner: room.state.winner, duration: Math.max(0, Math.floor((Date.now()-room.state.startedAt)/1000)) }).onConflictDoNothing().catch(e => { recorded.delete(id); console.error('Match history persistence failed:', e.message); });
      }
    }
  }
  async function load(code) {
    if (rooms.has(code)) return rooms.get(code);
    if (loads.has(code)) return loads.get(code);
    const promise = (async () => {
      const [row] = await db.select().from(gameRooms).where(and(eq(gameRooms.code,code),gt(gameRooms.expiresAt,new Date()))).limit(1);
      if (!row) return null;
      const room = row.snapshot;
      room.players.forEach(p => { p.online = !!p.bot; });
      if (room.state?.status === 'playing' && !room.pausedAt) room.pausedAt = room.updatedAt;
      rooms.set(code,room); return room;
    })();
    loads.set(code,promise); try { return await promise; } finally { loads.delete(code); }
  }
  function updatePause(room) {
    if (room.state?.status !== 'playing') { room.pausedAt = null; return; }
    const offline = room.players.some(p => !p.online);
    if (offline && !room.pausedAt) room.pausedAt = Date.now();
    else if (!offline && room.pausedAt) { resumeClock(room.state,Date.now()-room.pausedAt); room.pausedAt = null; }
  }
  function attach(socket, room) {
    const player = room.players.find(p => p.id === socket.data.playerId);
    if (!player) throw new Error('This session does not belong to that player.');
    socket.data.room = room.code; socket.join(room.code); player.online = true; updatePause(room); publish(room);
  }
  function roomFor(socket) { const room = rooms.get(socket.data.room); if (!room || !room.players.some(p => p.id === socket.data.playerId)) throw new Error('Join a room first.'); return room; }
  function hostOnly(socket, room) { if (room.hostId !== socket.data.playerId) throw new Error('Only the room creator can do that.'); }
  function start(room) {
    if (room.state?.status === 'playing') throw new Error('A match is already running.');
    if (room.mode === 'online' && room.players.length !== 2) throw new Error('Invite a friend before starting.');
    if (room.players.some(p => !p.ready || !p.online)) throw new Error('Both players must be online and ready.');
    room.matchNo++; room.state = createGame(room.selectedGame,room.players.map(p => p.id)); room.status = 'playing'; room.pausedAt = null;
    message(room,`${GAMES.find(g => g.id === room.selectedGame).name} has started. Good luck!`); publish(room);
  }
  function setState(room, state) { room.state = state; room.status = state.status === 'finished' ? 'finished' : 'playing'; publish(room); }

  io.use((socket,next) => {
    const token = socket.handshake.auth?.token;
    if (typeof token !== 'string' || !/^[a-f0-9-]{36,80}$/i.test(token)) return next(new Error('A valid private session is required.'));
    socket.data.playerId = createHash('sha256').update(token).digest('hex').slice(0,32); next();
  });

  io.on('connection', socket => {
    const id = socket.data.playerId;
    socket.emit('identity',{id});
    io.emit('presence',{online: new Set([...io.sockets.sockets.values()].map(s => s.data.playerId)).size});
    const boot = (async () => {
      let room = [...rooms.values()].find(r => r.players.some(p => p.id === id));
      if (!room) { const [row] = await db.select().from(gameRooms).where(and(gt(gameRooms.expiresAt,new Date()),sql`${gameRooms.snapshot}->'players' @> ${JSON.stringify([{id}])}::jsonb`)).orderBy(desc(gameRooms.updatedAt)).limit(1); if (row) room = await load(row.code); }
      if (room && socket.connected) attach(socket,room);
    })().catch(e => { console.error('Session recovery failed:',e.message); socket.emit('server:notice','Could not restore your saved room. You can try reconnecting.'); });
    let bucketAt = Date.now(), requests = 0, lastChat = 0;
    function on(event, handler) {
      socket.on(event, async (payload, ack) => {
        const reply = typeof ack === 'function' ? ack : () => {};
        try {
          await boot;
          if (Date.now()-bucketAt > 10000) { bucketAt = Date.now(); requests = 0; }
          if (++requests > 140) throw new Error('Slow down for a moment, then try again.');
          if (!payload || typeof payload !== 'object' || Array.isArray(payload)) throw new Error('Invalid request.');
          const result = await handler(payload); reply({ok:true,...result});
        } catch (e) { reply({ok:false,error:e.message || 'Something went wrong. Please try again.'}); }
      });
    }
    on('room:create', async p => {
      if (socket.data.room) throw new Error('Leave your current room before creating another.');
      const limits = creationLimits.get(id) || {at:Date.now(),count:0}; if (Date.now()-limits.at > 60000) { limits.at = Date.now(); limits.count = 0; } if (++limits.count > 8) throw new Error('Please wait a minute before creating more rooms.'); creationLimits.set(id,limits);
      if (rooms.size > 1500) throw new Error('The hub is busy. Please try again shortly.');
      if (p.game && !GAMES.some(g => g.id === p.game)) throw new Error('Choose a game from the collection.');
      let code; for (let n = 0; n < 10; n++) { code = Array.from({length:6},() => ALPHABET[randomInt(ALPHABET.length)]).join(''); const [exists] = await db.select({code:gameRooms.code}).from(gameRooms).where(eq(gameRooms.code,code)).limit(1); if (!exists && !rooms.has(code)) break; code = null; } if (!code) throw new Error('Could not make a room. Please retry.');
      const name = typeof p.name === 'string' ? p.name.trim().slice(0,20) : 'Player';
      const room = { code,hostId:id,selectedGame:p.game || 'chess',mode:p.mode === 'solo' ? 'solo' : 'online',status:'lobby',players:[{id,name:name || 'Player',avatar:AVATARS.includes(p.avatar) ? p.avatar : AVATARS[0],ready:true,online:true}],messages:[],state:null,createdAt:Date.now(),updatedAt:Date.now(),matchNo:0,pausedAt:null };
      if (room.mode === 'solo' && BOT_GAMES.includes(room.selectedGame)) room.players.push({id:'cpu',name:'Practice Bot',avatar:'🤖',ready:true,online:true,bot:true});
      rooms.set(code,room); socket.data.room = code; socket.join(code); message(room,room.mode === 'solo' ? 'Solo practice. Bot opponents are clearly labeled.' : 'Room created. Share the link and bring a friend.'); await save(room); publish(room,false);
      if (room.mode === 'solo') start(room);
      return {code};
    });
    on('room:join', async p => {
      const code = String(p.code || '').trim().toUpperCase(); if (!/^[A-Z2-9]{6}$/.test(code)) throw new Error('Enter a valid 6-character room code.');
      if (socket.data.room && socket.data.room !== code) throw new Error('Leave your current room before joining another.');
      const room = await load(code); if (!room || room.mode !== 'online') throw new Error('Room not found. Check the code with your friend.');
      const existing = room.players.find(p => p.id === id);
      if (!existing) { if (room.players.length >= 2 || room.status === 'playing') throw new Error('This room is full or a match is in progress.'); room.players.push({id,name:String(p.name || 'Player').trim().slice(0,20) || 'Player',avatar:AVATARS.includes(p.avatar) ? p.avatar : AVATARS[1],ready:false,online:true}); room.state = null; room.status = 'lobby'; message(room,`${room.players.at(-1).name} joined. Let the good games begin.`); }
      attach(socket,room); return {code};
    });
    on('room:select', p => { const room = roomFor(socket); hostOnly(socket,room); if (room.status === 'playing') throw new Error('Finish the current match before changing games.'); if (!GAMES.some(g => g.id === p.game)) throw new Error('Unknown game.'); room.selectedGame = p.game; room.state = null; room.status = 'lobby'; room.players.forEach(p => { p.ready = p.id === room.hostId || !!p.bot; }); publish(room); return {}; });
    on('room:ready', () => { const room = roomFor(socket); if (room.status === 'playing') throw new Error('The match is already running.'); const p = room.players.find(p => p.id === id); p.ready = !p.ready; publish(room); return {}; });
    on('room:start', () => { const room = roomFor(socket); hostOnly(socket,room); start(room); return {}; });
    on('game:move', p => {
      const room = roomFor(socket); if (!room.state) throw new Error('Start a game first.'); if (room.pausedAt) throw new Error('Waiting for your friend to reconnect.');
      if (TURN_GAMES.includes(room.selectedGame) && p.rev !== room.state.rev) throw new Error('The board changed. Please make your move again.');
      if (!p.action || typeof p.action !== 'object' || typeof p.action.type !== 'string') throw new Error('Invalid move.');
      setState(room,applyAction(room.state,id,p.action)); return {};
    });
    on('room:rematch', () => { const room = roomFor(socket); if (room.status === 'playing') throw new Error('Finish this match first.'); room.state = null; room.status = 'lobby'; room.players.forEach(p => {p.ready = p.id === room.hostId || !!p.bot;}); message(room,'Another round? Ready up for a rematch.'); if (room.mode === 'solo') start(room); else publish(room); return {}; });
    on('chat:send', p => { const room = roomFor(socket); const text = String(p.text || '').trim().slice(0,220); if (!text) throw new Error('Write a message first.'); if (Date.now()-lastChat < 450) throw new Error('Give your friend a moment to read!'); lastChat = Date.now(); room.messages.push({id:randomUUID(),playerId:id,name:room.players.find(p => p.id === id).name,text,at:Date.now()}); room.messages = room.messages.slice(-80); publish(room); return {}; });
    on('room:leave', async () => {
      const room = roomFor(socket), player = room.players.find(p => p.id === id);
      if (room.state?.status === 'playing') { room.state.status = 'finished'; room.state.winner = room.players.find(p => p.id !== id)?.id || 'draw'; room.state.data.result = 'Your opponent left the room'; room.status = 'finished'; publish(room); }
      room.players = room.players.filter(p => p.id !== id); message(room,`${player.name} left the room.`);
      for (const s of io.sockets.sockets.values()) if (s.data.playerId === id && s.data.room === room.code) { s.leave(room.code); s.data.room = null; s.emit('room:left'); }
      if (!room.players.some(p => !p.bot)) { rooms.delete(room.code); await (saves.get(room.code) || Promise.resolve()).catch(() => {}); await db.delete(gameRooms).where(eq(gameRooms.code,room.code)); saves.delete(room.code); }
      else { if (room.hostId === id) room.hostId = room.players[0].id; updatePause(room); publish(room); }
      return {};
    });
    on('profile:history', async () => { const history = await db.select().from(gameMatches).where(sql`${gameMatches.players} @> ${JSON.stringify([{id}])}::jsonb`).orderBy(desc(gameMatches.finishedAt)).limit(40); return {history}; });
    socket.on('disconnect', () => {
      const room = rooms.get(socket.data.room); if (room && ![...io.sockets.sockets.values()].some(s => s.data.playerId === id && s.data.room === room.code)) { const p = room.players.find(p => p.id === id); if (p) p.online = false; updatePause(room); publish(room); }
      io.emit('presence',{online:new Set([...io.sockets.sockets.values()].map(s => s.data.playerId)).size});
    });
  });

  const timer = setInterval(() => {
    const now = Date.now();
    for (const room of rooms.values()) {
      if (!room.state || room.state.status !== 'playing' || room.pausedAt) continue;
      let state = tickGame(room.state,now);
      if (state !== room.state) { room.state = state; room.status = state.status === 'finished' ? 'finished' : 'playing'; publish(room,state.status === 'finished' || !room.lastSavedTick || now-room.lastSavedTick > 1200); if (!room.lastSavedTick || now-room.lastSavedTick > 1200) room.lastSavedTick = now; }
      if (state.status === 'playing' && room.mode === 'solo' && (!room.botAt || now-room.botAt > 700)) { const action = botAction(state,'cpu'); if (action) { room.botAt = now; try { setState(room,applyAction(state,'cpu',action,now)); } catch { /* A pending card or round can delay the bot. */ } } }
    }
    if (now-lastPrune > 3600000) { lastPrune = now; for (const [code,room] of rooms) if (now-room.updatedAt > TTL) rooms.delete(code); db.delete(gameRooms).where(sql`${gameRooms.expiresAt} < now()`).catch(console.error); creationLimits.clear(); }
  },100);
  timer.unref();
  io.gamehubClose = async () => { clearInterval(timer); await new Promise(resolve => io.close(resolve)); await Promise.allSettled([...saves.values()]); };
  return io;
}

async function startStandalone() {
  if (!globalThis.__gamehubRealtimePromise) globalThis.__gamehubRealtimePromise = (async () => {
    const app = express(), server = createServer(app); createRealtimeServer(server);
    app.get('/healthz',(_req,res) => res.json({ok:true}));
    await new Promise((resolve,reject) => { server.once('error',reject); server.listen(Number(process.env.REALTIME_PORT || 3001),'127.0.0.1',resolve); });
    return server;
  })().catch(error => { globalThis.__gamehubRealtimePromise = null; throw error; });
  return globalThis.__gamehubRealtimePromise;
}
module.exports = { createRealtimeServer, startStandalone };

if (require.main === module) {
  process.env.GAMEHUB_CUSTOM_SERVER = '1';
  const next = require('next');
  const port = Number(process.env.PORT || 3000), dev = process.env.NODE_ENV !== 'production';
  const nextApp = next({dev,hostname:'0.0.0.0',port});
  nextApp.prepare().then(() => {
    const app = express(), server = createServer(app), io = createRealtimeServer(server);
    app.disable('x-powered-by');
    app.get('/index.html',(_req,res) => res.sendFile(require('node:path').join(__dirname,'index.html')));
    app.get('/style.css',(_req,res) => res.sendFile(require('node:path').join(__dirname,'style.css')));
    app.get('/script.js',(_req,res) => res.sendFile(require('node:path').join(__dirname,'script.js')));
    app.use((req,res) => nextApp.getRequestHandler()(req,res));
    server.listen(port,'0.0.0.0',() => console.log(`GAMEHUB is accepting connections on port ${port}`));
    const stop = async () => { const force = setTimeout(() => process.exit(0),8000); force.unref(); await io.gamehubClose(); server.close(() => { clearTimeout(force); process.exit(0); }); };
    process.on('SIGTERM',stop); process.on('SIGINT',stop);
  }).catch(error => {console.error(error);process.exit(1);});
}
