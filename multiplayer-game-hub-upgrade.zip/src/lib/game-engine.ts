/* eslint-disable @typescript-eslint/no-explicit-any */
import { Chess } from "chess.js";
import { GAMES, TURN_GAMES } from "./catalog";
import type { GameState, GameAction } from "./types";

const rand = (n: number) => Math.floor(Math.random() * n);
const range = (n: number) => Array.from({ length: n }, (_, i) => i);
export function shuffle<T>(items: T[]): T[] { const a = [...items]; for (let i = a.length - 1; i > 0; i--) { const j = rand(i + 1); [a[i], a[j]] = [a[j], a[i]]; } return a; }
const empty = (n: number) => Array(n).fill(0) as number[];
const WORDS = ["PLANET", "BRIDGE", "CASTLE", "JUNGLE", "ROCKET", "GARDEN", "PUZZLE", "SILVER", "WONDER", "FRIEND", "ORANGE", "ARCADE", "GALAXY", "MONKEY", "BOTTLE", "SUNSET", "CANDLE", "FOREST", "WINTER", "SUMMER", "PIRATE", "DRAGON", "OCEAN", "THUNDER"];
import { SHAPES } from "./shapes";
const SOLUTION = "534678912672195348198342567859761423426853791713924856961537284287419635345286179";
const PUZZLE = "530070000600195000098000060800060003400803001700020006060000280000419005000080079";
const each = <T,>(players: string[], fn: () => T): Record<string, T> => Object.fromEntries(players.map(p => [p, fn()]));
const nextTurn = (s: GameState) => { s.turn = s.players[(s.players.indexOf(s.turn || "") + 1) % s.players.length]; };
const end = (s: GameState, winner: string, reason: string) => { s.status = "finished"; s.winner = winner; s.data.result = reason; s.turn = null; };
function scoreEnd(s: GameState, reason = "Time is up") { const best = Math.max(...Object.values(s.scores)); const winners = s.players.filter(p => s.scores[p] === best); end(s, winners.length === 1 && !(s.players.length === 1 && s.data.dead?.[winners[0]]) ? winners[0] : "draw", reason); }
function allDead(s: GameState) { if (s.players.every(p => s.data.dead[p])) scoreEnd(s, "All attempts are complete"); }
function indexOf(a: GameAction, length: number): number { if (!Number.isInteger(a.index) || a.index! < 0 || a.index! >= length) throw new Error("Choose a valid square."); return a.index!; }
function neighbors(i: number, size: number, diagonals = true): number[] { const r = Math.floor(i / size), c = i % size, a: number[] = []; for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) { if ((!dr && !dc) || (!diagonals && dr && dc)) continue; const y = r + dr, x = c + dc; if (y >= 0 && y < size && x >= 0 && x < size) a.push(y * size + x); } return a; }
function hasLine(board: number[], rows: number, cols: number, length: number, mark: number): boolean { for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) for (const [dr, dc] of [[0,1],[1,0],[1,1],[1,-1]]) { let n = 0; for (; n < length; n++) { const y = r + dr * n, x = c + dc * n; if (y < 0 || y >= rows || x < 0 || x >= cols || board[y * cols + x] !== mark) break; } if (n === length) return true; } return false; }
function chessData(s: GameState, chess: Chess) { s.data.fen = chess.fen(); s.data.pgn = chess.pgn(); s.data.board = chess.board().flat().map(p => p ? p.color + p.type : ""); s.data.legalMoves = chess.moves({ verbose: true }).map(m => ({ from: m.from, to: m.to })); s.data.check = chess.inCheck(); s.turn = s.players[chess.turn() === "w" ? 0 : 1]; }
function fits(board: number[], shape: number[][], i: number) { const r = Math.floor(i / 8), c = i % 8; return shape.every(([y,x]) => r+y < 8 && c+x < 8 && !board[(r+y)*8+c+x]); }
function toggleLights(board: number[], i: number) { [i, ...neighbors(i, 5, false)].forEach(j => { board[j] = 1 - board[j]; }); }
function spawn2048(board: number[]) { const free = range(16).filter(i => !board[i]); if (free.length) board[free[rand(free.length)]] = Math.random() < .9 ? 2 : 4; }
export function slide2048(board: number[], direction: string): { board: number[]; score: number } { const next = [...board]; let score = 0; for (let line = 0; line < 4; line++) { const indices = range(4).map(j => direction === "left" ? line*4+j : direction === "right" ? line*4+3-j : direction === "up" ? j*4+line : (3-j)*4+line); const values = indices.map(i => board[i]).filter(Boolean); const merged: number[] = []; for (let j = 0; j < values.length; j++) { if (values[j] === values[j+1]) { merged.push(values[j]*2); score += values[j]*2; j++; } else merged.push(values[j]); } indices.forEach((i,j) => { next[i] = merged[j] || 0; }); } return { board: next, score }; }

export function createGame(game: string, players: string[], now = Date.now()): GameState {
  if (!GAMES.some(g => g.id === game) || !players.length || players.length > 2) throw new Error("Invalid game or players.");
  const s: GameState = { game, players, turn: TURN_GAMES.includes(game) ? players[0] : null, scores: each(players, () => 0), status: "playing", winner: null, startedAt: now, endsAt: null, rev: 0, data: { dead: each(players, () => false), moves: each(players, () => 0) } };
  const d = s.data;
  switch (game) {
    case "chess": chessData(s, new Chess()); break;
    case "tictactoe": d.board = empty(9); break;
    case "connect4": d.board = empty(42); break;
    case "sos": d.board = Array(25).fill(""); d.lines = []; break;
    case "dots": d.edges = empty(24); d.boxes = empty(9); break;
    case "bingo": d.cards = each(players, () => shuffle(range(25).map(n => n+1))); d.drawn = []; d.bag = shuffle(range(25).map(n => n+1)); break;
    case "rps": d.choices = {}; d.round = 1; d.lastRound = null; d.nextRoundAt = now; break;
    case "hangman": d.word = WORDS[rand(WORDS.length)]; d.guessed = each(players, () => []); s.endsAt = now + 180000; break;
    case "memory": d.cards = shuffle([...range(8), ...range(8)]); d.matched = Array(16).fill(""); d.revealed = []; d.pendingUntil = null; break;
    case "blocks": d.boards = each(players, () => empty(64)); d.pieces = each(players, () => range(3).map(() => rand(SHAPES.length))); s.endsAt = now + 120000; break;
    case "snake": d.snakes = each(players, () => [65,64,63]); d.directions = each(players, () => "right"); d.queued = each(players, () => "right"); d.food = each(players, () => 89); d.nextTick = now + 250; s.endsAt = now + 120000; break;
    case "2048": { const b = empty(16); spawn2048(b); spawn2048(b); d.boards = each(players, () => [...b]); s.endsAt = now + 120000; break; }
    case "mines": d.mines = shuffle(range(36).filter(i => ![0,1,6,7].includes(i))).slice(0,6); d.revealed = each(players, () => Array(36).fill(false)); d.flags = each(players, () => Array(36).fill(false)); s.endsAt = now + 180000; break;
    case "sudoku": { const digits = shuffle(range(9).map(i => i+1)); d.solution = SOLUTION.split("").map(n => digits[Number(n)-1]); d.givens = PUZZLE.split("").map(n => n === "0" ? 0 : digits[Number(n)-1]); d.boards = each(players, () => [...d.givens]); d.mistakes = each(players, () => 0); s.endsAt = now + 300000; break; }
    case "number": d.target = rand(100)+1; d.low = 1; d.high = 100; d.lastGuess = null; break;
    case "word": { d.answer = WORDS[rand(WORDS.length)]; let text = shuffle(d.answer.split("")).join(""); if (text === d.answer) text = text.slice(1)+text[0]; d.scrambled = text; d.attempts = each(players, () => 0); s.endsAt = now + 120000; break; }
    case "simon": d.sequence = range(10).map(() => rand(4)); d.level = each(players, () => 1); d.step = each(players, () => 0); d.errors = each(players, () => 0); d.readyAt = each(players, () => now + 1500); s.endsAt = now + 180000; break;
    case "mole": d.mole = rand(9); d.moleRound = 0; d.hitRound = each(players, () => -1); d.nextMoleAt = now + 850; s.endsAt = now + 45000; break;
    case "sliding": { const b = [...range(15).map(n => n+1),0]; let last = -1; for (let n = 0; n < 160; n++) { const z = b.indexOf(0), possible = neighbors(z,4,false).filter(i => i !== last); const i = possible[rand(possible.length)]; [b[z],b[i]] = [b[i],b[z]]; last = z; } d.boards = each(players, () => [...b]); players.forEach(p => { s.scores[p] = b.filter((v,i) => v && v === i+1).length; }); s.endsAt = now + 180000; break; }
    case "lights": { const b = empty(25); shuffle(range(25)).slice(0,12).forEach(i => toggleLights(b,i)); d.boards = each(players, () => [...b]); players.forEach(p => { s.scores[p] = b.filter(v => !v).length; }); s.endsAt = now + 180000; break; }
  }
  return s;
}

export function applyAction(current: GameState, player: string, action: GameAction, now = Date.now()): GameState {
  if (current.status !== "playing") throw new Error("This match has finished.");
  if (!current.players.includes(player)) throw new Error("You are not a player in this match.");
  if (current.endsAt && now >= current.endsAt) throw new Error("Time is up.");
  if (TURN_GAMES.includes(current.game) && current.turn !== player) throw new Error("It is your friend's turn.");
  if (current.data.dead[player]) throw new Error("Your attempt is complete. Your friend is still playing.");
  const s = structuredClone(current), d = s.data, mark = s.players.indexOf(player)+1;
  switch (s.game) {
    case "chess": {
      const chess = new Chess(); if (d.pgn) chess.loadPgn(d.pgn);
      if (!action.from || !action.to) throw new Error("Select a piece and a destination.");
      const promotion = typeof action.value === "string" && ["q","r","b","n"].includes(action.value) ? action.value : "q";
      const move = chess.move({ from: action.from, to: action.to, promotion });
      if (move.captured) s.scores[player] += ({ p:1,n:3,b:3,r:5,q:9,k:0 }[move.captured] || 0);
      d.lastMove = [move.from,move.to]; chessData(s,chess);
      if (chess.isGameOver()) end(s, chess.isCheckmate() ? player : "draw", chess.isCheckmate() ? "Checkmate" : "Draw by chess rules");
      break;
    }
    case "tictactoe": { const i = indexOf(action,9); if (d.board[i]) throw new Error("That square is taken."); d.board[i] = mark; if (hasLine(d.board,3,3,3,mark)) { s.scores[player] = 1; end(s,player,"Three in a row!"); } else if (d.board.every(Boolean)) end(s,"draw","The board is full"); else nextTurn(s); break; }
    case "connect4": { const col = indexOf(action,7); let i = 35+col; while (i >= 0 && d.board[i]) i -= 7; if (i < 0) throw new Error("That column is full."); d.board[i] = mark; d.lastCell = i; if (hasLine(d.board,6,7,4,mark)) { s.scores[player] = 1; end(s,player,"Four connected!"); } else if (d.board.every(Boolean)) end(s,"draw","The board is full"); else nextTurn(s); break; }
    case "sos": {
      const i = indexOf(action,25), letter = String(action.value).toUpperCase(); if (!["S","O"].includes(letter) || d.board[i]) throw new Error("Pick S or O and an empty square."); d.board[i] = letter; let points = 0;
      for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) for (const [dr,dc] of [[0,1],[1,0],[1,1],[1,-1]]) { const cells = range(3).map(n => [r+dr*n,c+dc*n]); if (cells.some(([y,x]) => y < 0 || y >= 5 || x < 0 || x >= 5)) continue; const ids = cells.map(([y,x]) => y*5+x), key = ids.join("-"); if (ids.includes(i) && ids.map(j => d.board[j]).join("") === "SOS" && !d.lines.includes(key)) { d.lines.push(key); points++; } }
      s.scores[player] += points; if (d.board.every(Boolean)) scoreEnd(s,"Every square is filled"); else if (!points) nextTurn(s); break;
    }
    case "dots": { const i = indexOf(action,24); if (d.edges[i]) throw new Error("That edge is already connected."); d.edges[i] = mark; let points = 0; for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) { const box = r*3+c; if (!d.boxes[box] && [r*3+c,(r+1)*3+c,12+r*4+c,12+r*4+c+1].every(e => d.edges[e])) { d.boxes[box] = mark; points++; } } s.scores[player] += points; if (d.boxes.every(Boolean)) scoreEnd(s,"All boxes claimed"); else if (!points) nextTurn(s); break; }
    case "bingo": { if (action.type !== "draw") throw new Error("Draw a number to play."); const n = d.bag.pop(); if (!n) throw new Error("No numbers remain."); d.drawn.push(n); d.lastNumber = n; const winners = s.players.filter(p => { const card: number[] = d.cards[p]; const b = card.map(v => d.drawn.includes(v) ? 1 : 0); s.scores[p] = b.filter(Boolean).length; return hasLine(b,5,5,5,1); }); if (winners.length) end(s,winners.length === 1 ? winners[0] : "draw","Bingo!"); else nextTurn(s); break; }
    case "rps": {
      const choice = String(action.value); if (!["rock","paper","scissors"].includes(choice)) throw new Error("Choose rock, paper, or scissors."); if (now < d.nextRoundAt) throw new Error("The next round starts in a moment."); if (d.choices[player]) throw new Error("Your choice is locked in."); d.choices[player] = choice;
      if (s.players.every(p => d.choices[p])) { const [a,b] = s.players, ca = d.choices[a], cb = d.choices[b]; const winner = ca === cb ? "draw" : ({rock:"scissors",paper:"rock",scissors:"paper"} as Record<string,string>)[ca] === cb ? a : b; if (winner !== "draw") s.scores[winner]++; d.lastRound = { choices: {...d.choices}, winner }; d.choices = {}; d.round++; d.nextRoundAt = now+1100; if (winner !== "draw" && s.scores[winner] >= 3) end(s,winner,"First to three!"); } break;
    }
    case "hangman": { const letter = String(action.value).toUpperCase(); if (!/^[A-Z]$/.test(letter) || d.guessed[player].includes(letter)) throw new Error("Choose a new letter."); d.guessed[player].push(letter); const known = d.word.split("").filter((c: string) => d.guessed[player].includes(c)).length; s.scores[player] = known; const wrong = d.guessed[player].filter((c: string) => !d.word.includes(c)).length; if (known === d.word.length) end(s,player,"Word solved!"); else if (wrong >= 6) { d.dead[player] = true; allDead(s); } break; }
    case "memory": { const i = indexOf(action,16); if (d.pendingUntil || d.matched[i] || d.revealed.includes(i)) throw new Error("Choose a face-down card."); d.revealed.push(i); if (d.revealed.length === 2) { const [a,b] = d.revealed; if (d.cards[a] === d.cards[b]) { d.matched[a] = player; d.matched[b] = player; d.revealed = []; s.scores[player]++; if (d.matched.every(Boolean)) scoreEnd(s,"All pairs found"); } else d.pendingUntil = now+1100; } break; }
    case "blocks": { const i = indexOf(action,64), piece = action.piece; if (!Number.isInteger(piece) || piece! < 0 || piece! > 2 || d.pieces[player][piece!] === null) throw new Error("Select an available piece."); const shape = SHAPES[d.pieces[player][piece!]], b: number[] = d.boards[player]; if (!fits(b,shape,i)) throw new Error("That piece does not fit there."); const r = Math.floor(i/8), c = i%8; shape.forEach(([y,x]) => { b[(r+y)*8+c+x] = 1; }); s.scores[player] += shape.length; const clear = new Set<number>(); for (let n = 0; n < 8; n++) { const row = range(8).map(j => n*8+j), col = range(8).map(j => j*8+n); if (row.every(j => b[j])) row.forEach(j => clear.add(j)); if (col.every(j => b[j])) col.forEach(j => clear.add(j)); } clear.forEach(j => { b[j] = 0; }); s.scores[player] += clear.size*2; d.pieces[player][piece!] = null; if (d.pieces[player].every((v: number | null) => v === null)) d.pieces[player] = range(3).map(() => rand(SHAPES.length)); if (!d.pieces[player].some((v: number | null) => v !== null && range(64).some(j => fits(b,SHAPES[v],j)))) { d.dead[player] = true; allDead(s); } break; }
    case "snake": { const dir = action.direction || ""; const opposite: Record<string,string> = {left:"right",right:"left",up:"down",down:"up"}; if (!opposite[dir] || opposite[dir] === d.directions[player]) throw new Error("You cannot reverse direction."); d.queued[player] = dir; break; }
    case "2048": { if (!["left","right","up","down"].includes(action.direction || "")) throw new Error("Choose a direction."); const b: number[] = d.boards[player], result = slide2048(b,action.direction!); if (b.every((v,i) => v === result.board[i])) throw new Error("No tiles can move that way."); d.boards[player] = result.board; s.scores[player] += result.score; spawn2048(result.board); if (result.board.includes(2048)) end(s,player,"2048 reached!"); else if (!["left","right","up","down"].some(dir => slide2048(result.board,dir).board.some((v,i) => v !== result.board[i]))) { d.dead[player] = true; allDead(s); } break; }
    case "mines": {
      const i = indexOf(action,36), revealed: boolean[] = d.revealed[player], flags: boolean[] = d.flags[player]; if (revealed[i]) throw new Error("That cell is already revealed."); if (action.type === "flag") { flags[i] = !flags[i]; break; } if (flags[i]) throw new Error("Remove the flag before revealing this cell.");
      if (d.mines.includes(i)) { revealed[i] = true; d.dead[player] = true; allDead(s); break; }
      const queue = [i]; while (queue.length) { const j = queue.pop()!; if (revealed[j] || d.mines.includes(j) || flags[j]) continue; revealed[j] = true; if (!neighbors(j,6).some(n => d.mines.includes(n))) queue.push(...neighbors(j,6).filter(n => !revealed[n])); }
      s.scores[player] = revealed.filter((v,j) => v && !d.mines.includes(j)).length; if (s.scores[player] === 30) end(s,player,"Minefield cleared!"); break;
    }
    case "sudoku": { const i = indexOf(action,81), n = Number(action.value); if (!Number.isInteger(n) || n < 1 || n > 9 || d.boards[player][i]) throw new Error("Select an empty cell and a number from 1 to 9."); if (d.solution[i] !== n) { d.mistakes[player]++; s.scores[player] = Math.max(0,s.scores[player]-1); } else { d.boards[player][i] = n; s.scores[player]++; if (d.boards[player].every(Boolean)) end(s,player,"Sudoku solved!"); } break; }
    case "number": { const n = Number(action.value); if (!Number.isInteger(n) || n < d.low || n > d.high) throw new Error(`Choose a number from ${d.low} to ${d.high}.`); s.scores[player]++; d.lastGuess = { player, number: n, hint: n === d.target ? "Exactly right!" : n < d.target ? "Go higher" : "Go lower" }; if (n === d.target) end(s,player,"You found the number!"); else { if (n < d.target) d.low = n+1; else d.high = n-1; nextTurn(s); } break; }
    case "word": { const answer = String(action.value).trim().toUpperCase(); if (!/^[A-Z]{2,20}$/.test(answer)) throw new Error("Enter a word using letters only."); d.attempts[player]++; if (answer === d.answer) { s.scores[player] = 1; end(s,player,"Word unscrambled!"); } else d.lastWrong = player; break; }
    case "simon": { const n = Number(action.value); if (!Number.isInteger(n) || n < 0 || n > 3) throw new Error("Choose a color."); if (now < d.readyAt[player]) throw new Error("Watch the sequence first."); if (n !== d.sequence[d.step[player]]) { d.errors[player]++; d.step[player] = 0; d.readyAt[player] = now + d.level[player]*650+850; if (d.errors[player] >= 3) { d.dead[player] = true; allDead(s); } } else { d.step[player]++; if (d.step[player] === d.level[player]) { s.scores[player] = d.level[player]; if (d.level[player] === 10) end(s,player,"Perfect memory! Ten levels complete."); else { d.level[player]++; d.step[player] = 0; d.readyAt[player] = now+d.level[player]*650+850; } } } break; }
    case "mole": { const i = indexOf(action,9); if (i !== d.mole || Number(action.value) !== d.moleRound || d.hitRound[player] === d.moleRound) throw new Error("That mole is already gone!"); d.hitRound[player] = d.moleRound; s.scores[player]++; break; }
    case "sliding": { const i = indexOf(action,16), b: number[] = d.boards[player], z = b.indexOf(0); if (!neighbors(z,4,false).includes(i)) throw new Error("Choose a tile next to the empty square."); [b[i],b[z]] = [b[z],b[i]]; s.scores[player] = b.filter((v,j) => v && v === j+1).length; if (s.scores[player] === 15) end(s,player,"Puzzle solved!"); break; }
    case "lights": { const i = indexOf(action,25), b: number[] = d.boards[player]; toggleLights(b,i); s.scores[player] = b.filter(v => !v).length; if (b.every(v => !v)) end(s,player,"All lights out!"); break; }
    default: throw new Error("Unknown game.");
  }
  d.moves[player]++; s.rev++; return s;
}

export function tickGame(current: GameState, now = Date.now()): GameState {
  if (current.status !== "playing") return current;
  const s = structuredClone(current), d = s.data; let changed = false;
  if (s.endsAt && now >= s.endsAt) { scoreEnd(s); s.rev++; return s; }
  if (s.game === "memory" && d.pendingUntil && now >= d.pendingUntil) { d.revealed = []; d.pendingUntil = null; nextTurn(s); changed = true; }
  if (s.game === "mole" && now >= d.nextMoleAt) { d.mole = rand(9); d.moleRound++; d.nextMoleAt = now+850; changed = true; }
  if (s.game === "snake" && now >= d.nextTick) {
    d.nextTick = now+230;
    for (const p of s.players) {
      if (d.dead[p]) continue; const body: number[] = d.snakes[p], dir = d.queued[p]; d.directions[p] = dir;
      const head = body[0], r = Math.floor(head/12), c = head%12, nr = r+(dir === "up" ? -1 : dir === "down" ? 1 : 0), nc = c+(dir === "left" ? -1 : dir === "right" ? 1 : 0), next = nr*12+nc;
      const eats = next === d.food[p]; if (nr < 0 || nr >= 12 || nc < 0 || nc >= 12 || (eats ? body : body.slice(0,-1)).includes(next)) { d.dead[p] = true; continue; }
      body.unshift(next); if (eats) { s.scores[p] += 10; const free = range(144).filter(i => !body.includes(i)); if (!free.length) { end(s,p,"Arena filled!"); break; } d.food[p] = free[rand(free.length)]; } else body.pop();
    }
    const alive = s.players.filter(p => !d.dead[p]); if (s.players.length === 2 && alive.length === 1) end(s,alive[0],"Last snake standing!"); else if (!alive.length) scoreEnd(s,"Snake battle complete"); changed = true;
  }
  if (changed) { s.rev++; return s; } return current;
}

export function publicState(current: GameState, viewer: string, now = Date.now()): GameState {
  const s = structuredClone(current), d = s.data;
  if (s.game === "number") delete d.target;
  if (s.game === "bingo") delete d.bag;
  if (s.game === "word") { if (s.status === "finished") d.revealedAnswer = d.answer; delete d.answer; }
  if (s.game === "sudoku") delete d.solution;
  if (s.game === "hangman") { const guessed: string[] = d.guessed[viewer] || []; d.masked = d.word.split("").map((c: string) => guessed.includes(c) ? c : "_"); d.wrong = guessed.filter(c => !d.word.includes(c)); if (s.status === "finished") d.revealedAnswer = d.word; delete d.word; }
  if (s.game === "memory") d.cards = d.cards.map((v: number,i: number) => d.matched[i] || d.revealed.includes(i) ? v : -1);
  if (s.game === "rps") { d.chosen = Object.keys(d.choices); d.choices = d.choices[viewer] ? {[viewer]:d.choices[viewer]} : {}; }
  if (s.game === "mines") { d.mineCells = range(36).map(i => d.revealed[viewer]?.[i] || s.status === "finished" || d.dead[viewer] ? d.mines.includes(i) ? -1 : neighbors(i,6).filter(j => d.mines.includes(j)).length : null); delete d.mines; }
  if (s.game === "simon") d.sequence = now < d.readyAt[viewer] ? d.sequence.slice(0,d.level[viewer]) : [];
  return s;
}

export function botAction(s: GameState, bot: string): GameAction | null {
  if (s.status !== "playing" || (s.turn && s.turn !== bot)) return null;
  const d = s.data, choose = <T,>(a: T[]) => a.length ? a[rand(a.length)] : null;
  switch (s.game) {
    case "chess": { const m = choose(d.legalMoves) as any; return m ? {type:"move",from:m.from,to:m.to} : null; }
    case "tictactoe": { const free = range(9).filter(i => !d.board[i]), mark = s.players.indexOf(bot)+1; for (const m of [mark,mark === 1 ? 2 : 1]) for (const i of free) { const b = [...d.board]; b[i] = m; if (hasLine(b,3,3,3,m)) return {type:"move",index:i}; } return {type:"move",index:free.includes(4) ? 4 : choose(free)!}; }
    case "connect4": return {type:"move",index:choose(range(7).filter(i => !d.board[i]))!};
    case "sos": return {type:"move",index:choose(range(25).filter(i => !d.board[i]))!,value:rand(2) ? "S" : "O"};
    case "dots": return {type:"move",index:choose(range(24).filter(i => !d.edges[i]))!};
    case "bingo": return {type:"draw"};
    case "number": return {type:"guess",value:Math.floor((d.low+d.high)/2)};
    case "memory": return d.pendingUntil ? null : {type:"move",index:choose(range(16).filter(i => !d.matched[i] && !d.revealed.includes(i)))!};
    case "rps": return !d.choices[bot] && d.choices[s.players.find(p => p !== bot)!] && Date.now() >= d.nextRoundAt ? {type:"choice",value:["rock","paper","scissors"][rand(3)]} : null;
    default: return null;
  }
}

export function resumeClock(s: GameState, delta: number) { s.startedAt += delta; if (s.endsAt) s.endsAt += delta; for (const key of ["nextTick","pendingUntil","nextMoleAt","nextRoundAt"]) if (s.data[key]) s.data[key] += delta; if (s.data.readyAt) Object.keys(s.data.readyAt).forEach(p => { s.data.readyAt[p] += delta; }); }
