/* eslint-disable @typescript-eslint/no-explicit-any */
export interface Player { id: string; name: string; avatar: string; ready: boolean; online: boolean; bot?: boolean; }
export interface ChatMessage { id: string; playerId: string; name: string; text: string; at: number; system?: boolean; }
export interface GameState { game: string; players: string[]; turn: string | null; scores: Record<string, number>; status: "playing" | "finished"; winner: string | null; startedAt: number; endsAt: number | null; rev: number; data: Record<string, any>; }
export interface Room { code: string; hostId: string; selectedGame: string; mode: "online" | "solo"; status: "lobby" | "playing" | "finished"; players: Player[]; messages: ChatMessage[]; state: GameState | null; createdAt: number; updatedAt: number; matchNo: number; pausedAt?: number | null; }
export interface GameAction { type: string; index?: number; value?: string | number; from?: string; to?: string; direction?: string; piece?: number; }
export interface ServerReply { ok: boolean; error?: string; code?: string; }
export interface Profile { name: string; avatar: string; }
export const AVATARS = ["👾", "🦊", "🐸", "🐼", "🤖", "🐱", "🦁", "🐙"];
