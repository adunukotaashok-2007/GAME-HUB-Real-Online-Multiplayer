// Shared visual geometry only. Authoritative game rules remain on the server.
export const SHAPES: number[][][] = [
  [[0,0]], [[0,0],[0,1]], [[0,0],[1,0]],
  [[0,0],[0,1],[0,2]], [[0,0],[1,0],[2,0]],
  [[0,0],[0,1],[1,0],[1,1]], [[0,0],[1,0],[1,1]],
  [[0,0],[0,1],[1,1]], [[0,0],[0,1],[0,2],[1,1]],
];
