"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { io, type Socket } from "socket.io-client";
import type { GameAction, Profile, Room, ServerReply } from "./types";

export function useHub() {
  const socketRef = useRef<Socket | null>(null);
  const roomRef = useRef<Room | null>(null);
  const [room,setRoom] = useState<Room | null>(null);
  const [me,setMe] = useState("");
  const [connection,setConnection] = useState<"connecting" | "connected" | "offline">("connecting");
  const [online,setOnline] = useState(0);
  const [profile,setProfile] = useState<Profile>({name:"Player",avatar:"👾"});
  const [busy,setBusy] = useState(false);
  const [toast,setToast] = useState("");
  const [recent,setRecent] = useState<string[]>([]);
  const notify = useCallback((text:string) => setToast(text),[]);
  useEffect(() => { if (!toast) return; const t = setTimeout(() => setToast(""),4200); return () => clearTimeout(t); },[toast]);
  useEffect(() => {
    let cancelled = false, retry: ReturnType<typeof setTimeout>;
    try { const saved = localStorage.getItem("gamehub-profile"); if (saved) {const p = JSON.parse(saved); if (typeof p.name === "string" && typeof p.avatar === "string") setProfile(p);} const r = localStorage.getItem("gamehub-recent"); if (r) setRecent(JSON.parse(r)); } catch { /* Storage is optional for browsing. */ }
    async function connect() {
      try {
        const response = await fetch("/api/realtime",{cache:"no-store"}); const config = await response.json();
        if (!response.ok || !config.ok) throw new Error("Realtime server unavailable");
        if (cancelled) return;
        let token = localStorage.getItem("gamehub-session");
        if (!token) { token = typeof crypto.randomUUID === "function" ? crypto.randomUUID() : Array.from(crypto.getRandomValues(new Uint8Array(32)),b => b.toString(16).padStart(2,"0")).join(""); localStorage.setItem("gamehub-session",token); }
        const socket = io(process.env.NEXT_PUBLIC_SOCKET_URL || undefined,{auth:{token},path:config.path || "/socket.io",addTrailingSlash:false,transports:config.websocket?["polling","websocket"]:["polling"],upgrade:config.websocket,reconnection:true,reconnectionDelay:800,reconnectionDelayMax:5000,timeout:15000});
        socketRef.current = socket;
        socket.on("connect",() => setConnection("connected"));
        socket.on("disconnect",() => setConnection("offline"));
        socket.on("connect_error",() => setConnection("offline"));
        socket.on("identity",({id}:{id:string}) => setMe(id));
        socket.on("presence",({online}:{online:number}) => setOnline(online));
        socket.on("server:notice",(text:string) => setToast(text));
        socket.on("room:state",(next:Room) => { roomRef.current = next; setRoom(next); if (next.state) setRecent(prev => { const values = [next.selectedGame,...prev.filter(g => g !== next.selectedGame)].slice(0,20); try {localStorage.setItem("gamehub-recent",JSON.stringify(values));} catch {} return values; }); });
        socket.on("room:left",() => {roomRef.current = null;setRoom(null);});
      } catch { if (!cancelled) {setConnection("offline");retry = setTimeout(connect,4000);} }
    }
    connect();
    return () => {cancelled = true;clearTimeout(retry);socketRef.current?.disconnect();socketRef.current = null;};
  },[]);
  const saveProfile = useCallback((next:Profile) => {setProfile(next);try {localStorage.setItem("gamehub-profile",JSON.stringify(next));} catch {}},[]);
  const send = useCallback(async (event:string,payload:object = {}):Promise<ServerReply & Record<string,unknown>> => {
    const socket = socketRef.current;
    if (!socket?.connected) {setToast("Connecting to the game server. Please try again in a moment.");return {ok:false};}
    setBusy(true);
    return new Promise(resolve => {socket.timeout(12000).emit(event,payload,(error:Error | null,result:ServerReply & Record<string,unknown>) => {setBusy(false);if (error) {setToast("The server took too long to reply. Reconnect before trying again.");resolve({ok:false});} else {if (!result.ok) setToast(result.error || "Please try again.");resolve(result);}});});
  },[]);
  const move = useCallback((action:GameAction) => {void send("game:move",{action,rev:roomRef.current?.state?.rev});},[send]);
  return {room,me,connection,online,profile,saveProfile,busy,toast,notify,recent,send,move};
}
