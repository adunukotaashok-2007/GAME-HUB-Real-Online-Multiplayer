import { pgTable, varchar, jsonb, timestamp, integer, index } from "drizzle-orm/pg-core";
import type { Room } from "@/lib/types";

export const gameRooms = pgTable("gamehub_rooms", {
  code: varchar("code", { length: 6 }).primaryKey(),
  snapshot: jsonb("snapshot").$type<Room>().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
}, t => [index("gamehub_rooms_expiry_idx").on(t.expiresAt)]);

export const gameMatches = pgTable("gamehub_matches", {
  id: varchar("id", { length: 80 }).primaryKey(),
  roomCode: varchar("room_code", { length: 6 }).notNull(),
  game: varchar("game", { length: 30 }).notNull(),
  mode: varchar("mode", { length: 10 }).notNull(),
  players: jsonb("players").$type<{ id: string; name: string; avatar: string }[]>().notNull(),
  scores: jsonb("scores").$type<Record<string, number>>().notNull(),
  winner: varchar("winner", { length: 64 }),
  duration: integer("duration_seconds").notNull(),
  finishedAt: timestamp("finished_at", { withTimezone: true }).defaultNow().notNull(),
}, t => [index("gamehub_matches_finished_idx").on(t.finishedAt)]);
