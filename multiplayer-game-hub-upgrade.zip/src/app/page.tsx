import GameHub from "@/components/game-hub";
export default function HomePage() { return <GameHub />; }
