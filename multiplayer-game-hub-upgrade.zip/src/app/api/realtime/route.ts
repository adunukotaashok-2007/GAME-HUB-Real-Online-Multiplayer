import { createRequire } from "node:module";
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET() {
  try {
    if (process.env.GAMEHUB_CUSTOM_SERVER !== "1") {
      // The managed Next preview proxies same-origin Socket.IO polling to this
      // private sidecar. Render uses server.js and native WebSockets instead.
      const runtimeRequire = createRequire(`${process.cwd()}/package.json`);
      const { startStandalone } = runtimeRequire("./server.js");
      await startStandalone();
    }
    const native = process.env.GAMEHUB_CUSTOM_SERVER === "1";
    return Response.json({ ok: true, websocket: native, path: native ? "/socket.io" : "/hub-socket" });
  } catch (error) {
    console.error("Realtime startup failed",error);
    return Response.json({ok:false,error:"The multiplayer server is not available. Please try again."},{status:503});
  }
}
