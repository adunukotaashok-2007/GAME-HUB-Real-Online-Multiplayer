require('dotenv').config({quiet:true});
const {test} = require('node:test');
const assert = require('node:assert/strict');
const {createServer} = require('node:http');
const {randomUUID} = require('node:crypto');
const {io:client} = require('socket.io-client');
const {createRealtimeServer} = require('../server');
const {pool} = require('../src/db/index.ts');
const sleep = ms => new Promise(r=>setTimeout(r,ms));
function connect(url,transport,token=randomUUID()){return new Promise((resolve,reject)=>{const s=client(url,{auth:{token},transports:[transport],forceNew:true,reconnection:false,autoConnect:false});s.on('room:state',room=>{s.lastRoom=room;});s.on('identity',({id})=>{s.playerId=id;});s.once('connect',()=>resolve(s));s.once('connect_error',reject);s.connect();});}
function send(s,event,p={}){return new Promise((resolve,reject)=>s.timeout(7000).emit(event,p,(e,r)=>e?reject(e):resolve(r)));}
async function wait(s,predicate){const until=Date.now()+7000;while(Date.now()<until){if(predicate(s.lastRoom))return s.lastRoom;await sleep(20);}throw new Error('Timed out waiting for synchronized room state');}

for(const transport of ['websocket','polling'])test(`real ${transport}: independent clients, host controls, moves, chat, reconnect and rematch`,{timeout:25000},async()=>{
 const http=createServer((_q,r)=>r.end('test')),server=createRealtimeServer(http);await new Promise(r=>http.listen(0,'127.0.0.1',r));const url=`http://127.0.0.1:${http.address().port}`;let a,b,c;
 try{
  a=await connect(url,transport);b=await connect(url,transport);
  let r=await send(a,'room:create',{name:'Phone A',avatar:'🦊',game:'chess'});assert.equal(r.ok,true);assert.match(r.code,/^[A-Z2-9]{6}$/);const code=r.code;
  r=await send(b,'room:join',{code,name:'Phone B',avatar:'🐸'});assert.equal(r.ok,true);await wait(a,s=>s?.players.length===2);assert.notEqual(a.playerId,b.playerId);assert.equal(a.lastRoom.players[1].name,'Phone B');
  c=await connect(url,transport);assert.equal((await send(c,'room:join',{code,name:'Third'})).ok,false);
  assert.equal((await send(b,'room:select',{game:'tictactoe'})).ok,false);
  assert.equal((await send(a,'room:select',{game:'tictactoe'})).ok,true);await wait(b,s=>s?.selectedGame==='tictactoe');
  assert.equal((await send(a,'room:start')).ok,false);assert.equal((await send(b,'room:ready')).ok,true);assert.equal((await send(a,'room:start')).ok,true);await wait(b,s=>s?.state?.game==='tictactoe');
  assert.equal((await send(b,'game:move',{rev:0,action:{type:'move',index:4}})).ok,false);
  assert.equal((await send(a,'game:move',{rev:0,action:{type:'move',index:0}})).ok,true);await wait(b,s=>s?.state?.rev===1);assert.equal(b.lastRoom.state.data.board[0],1);assert.equal(b.lastRoom.state.turn,b.playerId);
  assert.equal((await send(a,'game:move',{rev:0,action:{type:'move',index:1}})).ok,false);
  assert.equal((await send(b,'game:move',{rev:1,action:{type:'move',index:0}})).ok,false);
  assert.equal((await send(a,'chat:send',{text:'Real connection! 👋'})).ok,true);await wait(b,s=>s?.messages.some(m=>m.text==='Real connection! 👋'));
  b.disconnect();await wait(a,s=>s?.players.some(p=>p.id===b.playerId&&!p.online));assert.ok(a.lastRoom.pausedAt);assert.equal((await send(a,'game:move',{rev:1,action:{type:'move',index:1}})).ok,false);
  b.connect();await wait(a,s=>s?.players.every(p=>p.online)&&!s.pausedAt);await wait(b,s=>s?.state?.data.board[0]===1);assert.equal(b.lastRoom.code,code);
  for(const [socket,index] of [[b,3],[a,1],[b,4],[a,2]]){const expected=index===3?1:index===1?2:index===4?3:4;assert.equal((await send(socket,'game:move',{rev:expected,action:{type:'move',index}})).ok,true);await wait(a,s=>s?.state?.rev===expected+1);await wait(b,s=>s?.state?.rev===expected+1);}
  assert.equal(a.lastRoom.state.winner,a.playerId);assert.deepEqual(a.lastRoom.state.data.board,b.lastRoom.state.data.board);
  await sleep(160);const history=await send(a,'profile:history');assert.equal(history.ok,true);assert.ok(history.history.some(m=>m.roomCode===code&&m.winner===a.playerId));
  assert.equal((await send(a,'room:rematch')).ok,true);await wait(b,s=>s?.status==='lobby'&&!s.state);assert.equal(b.lastRoom.players.find(p=>p.id===b.playerId).ready,false);
  await send(b,'room:ready');assert.equal((await send(a,'room:start')).ok,true);await wait(b,s=>s?.matchNo===2&&s.state?.rev===0);assert.ok(b.lastRoom.state.data.board.every(v=>v===0));
  await send(a,'room:leave');await wait(b,s=>s?.hostId===b.playerId);assert.equal(b.lastRoom.state.winner,b.playerId);await send(b,'room:leave');
 }finally{a?.disconnect();b?.disconnect();c?.disconnect();await server.gamehubClose();await new Promise(r=>http.close(()=>r()));}
});

test('all 20 online games synchronize a validated action between independent clients',{timeout:45000},async t=>{
 const {GAMES}=require('../src/lib/catalog.ts');
 const {slide2048}=require('../src/lib/game-engine.ts');
 const http=createServer((_q,r)=>r.end('matrix')),server=createRealtimeServer(http);await new Promise(r=>http.listen(0,'127.0.0.1',r));const url=`http://127.0.0.1:${http.address().port}`;
 try{for(const game of GAMES)await t.test(`${game.name}: real online action`,async()=>{
  const a=await connect(url,'websocket'),b=await connect(url,'websocket');
  try{
   const made=await send(a,'room:create',{name:'Matrix A',avatar:'🦊',game:'chess'});assert.ok(made.ok,made.error);assert.ok((await send(b,'room:join',{code:made.code,name:'Matrix B',avatar:'🐸'})).ok);
   assert.ok((await send(a,'room:select',{game:game.id})).ok);await wait(b,r=>r?.selectedGame===game.id);await send(b,'room:ready');assert.ok((await send(a,'room:start')).ok);await wait(b,r=>r?.state?.game===game.id);
   const s=a.lastRoom.state,d=s.data,id=a.playerId;let action={type:'move',index:0};
   switch(game.id){
    case 'chess':action={type:'move',from:'e2',to:'e4'};break;
    case 'sos':action.value='S';break;
    case 'bingo':action={type:'draw'};break;
    case 'rps':action={type:'choice',value:'rock'};break;
    case 'hangman':action={type:'letter',value:'E'};break;
    case 'blocks':action={type:'place',index:0,piece:0};break;
    case 'snake':action={type:'direction',direction:'up'};break;
    case '2048':action={type:'direction',direction:['left','right','up','down'].find(dir=>slide2048(d.boards[id],dir).board.some((v,i)=>v!==d.boards[id][i]))};break;
    case 'mines':action={type:'reveal',index:0};break;
    case 'sudoku':action={type:'number',index:d.givens.findIndex(n=>!n),value:1};break;
    case 'number':action={type:'guess',value:50};break;
    case 'word':action={type:'guess',value:'PLANET'};break;
    case 'simon':action={type:'color',value:d.sequence[0]};await sleep(Math.max(0,d.readyAt[id]-Date.now()+20));break;
    case 'mole':action={type:'whack',index:d.mole,value:d.moleRound};break;
    case 'sliding':{const z=d.boards[id].indexOf(0);action.index=z%4?z-1:z+1;break;}
   }
   const result=await send(a,'game:move',{rev:a.lastRoom.state.rev,action});assert.ok(result.ok,`${game.name}: ${result.error}`);await wait(b,r=>r?.state?.data.moves[id]>=1);assert.deepEqual(a.lastRoom.state.scores,b.lastRoom.state.scores);assert.equal(b.lastRoom.state.game,game.id);
   if(game.id==='rps'){assert.equal(b.lastRoom.state.data.choices[id],undefined);assert.ok(b.lastRoom.state.data.chosen.includes(id));}
   if(game.id==='memory')assert.equal(b.lastRoom.state.data.cards.filter(v=>v>=0).length,1);
   if(game.id==='sudoku')assert.equal(b.lastRoom.state.data.solution,undefined);
   if(game.id==='word')assert.equal(b.lastRoom.state.data.answer,undefined);
   if(game.id==='mines')assert.equal(b.lastRoom.state.data.mines,undefined);
   await send(a,'room:leave');await send(b,'room:leave');
  }finally{a.disconnect();b.disconnect();}
 });}finally{await server.gamehubClose();await new Promise(r=>http.close(()=>r()));}
});

test('PostgreSQL restores a match on a fresh authoritative server',{timeout:20000},async()=>{
 const tokenA=randomUUID(),tokenB=randomUUID();
 async function start(){const http=createServer((_q,r)=>r.end('recovery')),server=createRealtimeServer(http);await new Promise(r=>http.listen(0,'127.0.0.1',r));return{http,server,url:`http://127.0.0.1:${http.address().port}`};}
 let runtime=await start(),a,b,code;
 try{
  a=await connect(runtime.url,'websocket',tokenA);b=await connect(runtime.url,'websocket',tokenB);const made=await send(a,'room:create',{name:'Restart A',game:'tictactoe'});code=made.code;await send(b,'room:join',{code,name:'Restart B'});await send(b,'room:ready');await send(a,'room:start');await send(a,'game:move',{rev:0,action:{type:'move',index:0}});await wait(b,r=>r?.state?.rev===1);
  a.disconnect();b.disconnect();await sleep(50);await runtime.server.gamehubClose();await new Promise(r=>runtime.http.close(()=>r()));
  runtime=await start();a=await connect(runtime.url,'websocket',tokenA);b=await connect(runtime.url,'websocket',tokenB);await wait(a,r=>r?.code===code&&r.players.every(p=>p.online)&&!r.pausedAt);await wait(b,r=>r?.state?.rev===1);assert.equal(b.lastRoom.state.data.board[0],1);assert.equal(b.lastRoom.state.turn,b.playerId);assert.ok((await send(b,'game:move',{rev:1,action:{type:'move',index:4}})).ok);await wait(a,r=>r?.state?.data.board[4]===2);await send(a,'room:leave');await send(b,'room:leave');
 }finally{a?.disconnect();b?.disconnect();await runtime.server.gamehubClose();await new Promise(r=>runtime.http.close(()=>r()));}
});

test('close test database pool',async()=>{await pool.end();});
