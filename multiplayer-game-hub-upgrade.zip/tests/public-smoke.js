// Two independent internet clients against an already deployed public URL.
const {io}=require('socket.io-client');
const {randomUUID}=require('node:crypto');
const assert=require('node:assert/strict');
const origin=process.argv[2];
if(!origin||!/^https:\/\//.test(origin)){console.error('Usage: node tests/public-smoke.js https://YOUR-SITE.onrender.com');process.exit(1);}
const sockets=[];let config;
const send=(s,e,p={})=>new Promise((resolve,reject)=>s.timeout(15000).emit(e,p,(err,r)=>err?reject(err):resolve(r)));
const connect=()=>new Promise((resolve,reject)=>{const s=io(origin,{auth:{token:randomUUID()},path:config.path||'/socket.io',addTrailingSlash:false,transports:config.websocket?['polling','websocket']:['polling'],forceNew:true,timeout:20000});sockets.push(s);s.on('room:state',r=>{s.room=r;});s.once('connect',()=>resolve(s));s.once('connect_error',reject);});
(async()=>{const response=await fetch(new URL('/api/realtime',origin));config=await response.json();assert.ok(config.ok,'Realtime startup failed');const a=await connect(),b=await connect();let r=await send(a,'room:create',{name:'Internet smoke A',avatar:'🦊',game:'tictactoe'});assert.ok(r.ok,r.error);const code=r.code;r=await send(b,'room:join',{code,name:'Internet smoke B',avatar:'🐸'});assert.ok(r.ok,r.error);await send(b,'room:ready');r=await send(a,'room:start');assert.ok(r.ok,r.error);r=await send(a,'game:move',{rev:0,action:{type:'move',index:0}});assert.ok(r.ok,r.error);await new Promise(r=>setTimeout(r,300));assert.equal(b.room.state.data.board[0],1);assert.equal(b.room.code,code);await send(a,'chat:send',{text:'Public internet smoke test ✓'});console.log('PASS: two independent public clients created/joined, selected, started, and synchronized a real move. Transport:',a.io.engine.transport.name);await send(a,'room:leave');await send(b,'room:leave');})().catch(e=>{console.error('FAIL:',e.message);process.exitCode=1;}).finally(()=>sockets.forEach(s=>s.disconnect()));
