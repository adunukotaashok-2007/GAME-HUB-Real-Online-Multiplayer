const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const fs=require('node:fs');
const base=process.env.TEST_URL||'http://127.0.0.1:3000';
(async()=>{
 const browser=await chromium.launch({headless:true,args:['--no-sandbox']});const errors=[];
 try{
  fs.mkdirSync('test-artifacts',{recursive:true});
  const desktop=await browser.newContext({viewport:{width:1440,height:1000}}),a=await desktop.newPage();a.on('pageerror',e=>errors.push(e.message));a.on('websocket',ws=>ws.on('socketerror',e=>errors.push('WebSocket: '+e)));
  await a.goto(base);await a.getByText('Multiplayer online',{exact:true}).waitFor({timeout:25000});await a.evaluate(()=>document.fonts.ready);await a.screenshot({path:'test-artifacts/desktop.png'});
  assert.equal(await a.locator('.game-card').count(),20);
  await a.getByLabel('Sort games').selectOption('quick');assert.equal(await a.locator('.game-card-title').first().innerText(),'Whack-a-Mole');await a.getByLabel('Sort games').selectOption('recommended');
  await a.locator('.category-filters').getByRole('button',{name:'Strategy',exact:true}).click();assert.equal(await a.locator('.game-card').count(),4);
  await a.locator('.category-filters').getByRole('button',{name:/All games/}).click();await a.getByLabel('Search games').fill('Mines');assert.equal(await a.locator('.game-card').count(),1);await a.getByLabel('Clear search').click();
  await a.getByLabel('Add Chess to favorites').click();await a.locator('.main-nav').getByRole('button',{name:/Favorites/}).click();assert.equal(await a.locator('.game-card').count(),1);await a.locator('.main-nav').getByRole('button',{name:/Discover/}).click();
  await a.getByRole('button',{name:'Create a room',exact:true}).click();await a.getByLabel('WHAT SHOULD WE CALL YOU?').fill('Desktop A');await a.locator('#create-game').selectOption('tictactoe');await a.getByRole('button',{name:'Create my room'}).click();await a.locator('.room-code').waitFor();const code=(await a.locator('.room-code').innerText()).trim();assert.match(code,/^[A-Z2-9]{6}$/);
  const mobile=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true}),b=await mobile.newPage();b.on('pageerror',e=>errors.push(e.message));await b.goto(`${base}/?room=${code}`);await b.getByLabel('WHAT SHOULD WE CALL YOU?').fill('Phone B');await b.getByRole('button',{name:'Join the good times'}).click();await b.locator('.room-code').waitFor();
  await a.screenshot({path:'test-artifacts/lobby.png'});await b.getByRole('button',{name:'I’m ready to play'}).click();await a.getByRole('button',{name:'Let’s play',exact:true}).click();await b.locator('.ttt-cell').first().waitFor();
  await a.locator('.ttt-cell').nth(0).click();await b.waitForFunction(()=>document.querySelectorAll('.ttt-cell')[0]?.textContent==='×');await b.locator('.ttt-cell').nth(4).click();await a.waitForFunction(()=>document.querySelectorAll('.ttt-cell')[4]?.textContent==='○');
  await b.getByLabel('Chat message',{exact:true}).fill('Hello from another device! 👋');await b.getByRole('button',{name:'Send chat message'}).click();await a.getByText('Hello from another device! 👋',{exact:true}).waitFor();
  await b.reload();await b.locator('.ttt-cell').first().waitFor();assert.equal(await b.locator('.ttt-cell').nth(0).innerText(),'×');
  await a.locator('.ttt-cell').nth(1).click();await b.waitForFunction(()=>document.querySelectorAll('.ttt-cell')[1]?.textContent==='×');await b.locator('.ttt-cell').nth(3).click();await a.waitForFunction(()=>document.querySelectorAll('.ttt-cell')[3]?.textContent==='○');await a.locator('.ttt-cell').nth(2).click();await b.locator('.match-result').waitFor();assert.ok((await a.locator('.match-result').innerText()).includes('This one’s yours!'));await a.screenshot({path:'test-artifacts/match.png'});await b.screenshot({path:'test-artifacts/mobile-match.png'});
  await a.getByRole('button',{name:'Play again',exact:true}).click();await b.getByRole('button',{name:'I’m ready to play'}).click();await a.getByRole('button',{name:'Let’s play',exact:true}).click();await b.locator('.ttt-cell').first().waitFor();assert.equal(await b.locator('.ttt-cell').nth(0).innerText(),'');
  for(const p of [a,b]){await p.getByRole('button',{name:'Leave room',exact:true}).click();await p.getByRole('dialog').getByRole('button',{name:'Leave room',exact:true}).click();}
  const phone=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true}),page=await phone.newPage();page.on('pageerror',e=>errors.push(e.message));await page.goto(base);await page.waitForTimeout(1200);await page.evaluate(()=>document.fonts.ready);await page.screenshot({path:'test-artifacts/mobile.png'});assert.equal(await page.locator('.game-card').count(),20);assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth),true,'Mobile should not overflow horizontally');
  await page.getByRole('button',{name:'Open navigation'}).click();await page.locator('.main-nav').getByRole('button',{name:/Play with friends/}).click();await page.getByText('Across the room.').waitFor();
  assert.deepEqual(errors,[]);console.log('PASS: desktop + mobile layouts, search, filters, favorites, actual two-browser room/moves/chat, refresh recovery, rematch, leaving and mobile navigation.');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
