import { test } from "node:test";
import assert from "node:assert/strict";
import { GAMES } from "../src/lib/catalog";
import { createGame, applyAction, tickGame, publicState, slide2048, resumeClock } from "../src/lib/game-engine";
import { SHAPES } from "../src/lib/shapes";
import type { GameAction, GameState } from "../src/lib/types";
const P = ["alice","bob"], NOW = Date.now();
const fresh = (id:string) => createGame(id,P,NOW);
const move = (s:GameState,p:string,a:GameAction,t=NOW+10) => applyAction(s,p,a,t);

for (const game of GAMES) test(`${game.name}: accepts an authoritative action and leaves the original immutable`,()=>{
  const s=fresh(game.id), d=s.data;let a:GameAction={type:"move",index:0},at=NOW+10;
  switch(game.id){
    case "chess":a={type:"move",from:"e2",to:"e4"};break;
    case "sos":a.value="S";break;
    case "bingo":a={type:"draw"};break;
    case "rps":a={type:"choice",value:"rock"};break;
    case "hangman":a={type:"letter",value:"E"};break;
    case "blocks":a={type:"place",index:0,piece:0};break;
    case "snake":a={type:"direction",direction:"up"};break;
    case "2048":a={type:"direction",direction:["left","right","up","down"].find(dir=>slide2048(d.boards.alice,dir).board.some((v,i)=>v!==d.boards.alice[i]))};break;
    case "mines":a={type:"reveal",index:0};break;
    case "sudoku":{const i=d.givens.findIndex((n:number)=>!n);a={type:"number",index:i,value:d.solution[i]};break;}
    case "number":a={type:"guess",value:50};break;
    case "word":a={type:"guess",value:d.answer};break;
    case "simon":a={type:"color",value:d.sequence[0]};at=d.readyAt.alice+1;break;
    case "mole":a={type:"whack",index:d.mole,value:d.moleRound};break;
    case "sliding":{const z=d.boards.alice.indexOf(0);a.index=z%4?z-1:z+1;break;}
  }
  const original=JSON.stringify(s),next=move(s,"alice",a,at);assert.equal(next.rev,1);assert.equal(JSON.stringify(s),original);assert.equal(next.data.moves.alice,1);
});

test("Tic-Tac-Toe: turn ownership, occupied squares, win and terminal rejection",()=>{
  let s=fresh("tictactoe");assert.throws(()=>move(s,"bob",{type:"move",index:0}),/turn/);s=move(s,"alice",{type:"move",index:0});assert.throws(()=>move(s,"bob",{type:"move",index:0}),/taken/);
  for(const [p,i] of [["bob",3],["alice",1],["bob",4],["alice",2]] as const)s=move(s,p,{type:"move",index:i});assert.equal(s.winner,"alice");assert.throws(()=>move(s,"bob",{type:"move",index:8}),/finished/);
});
test("Chess: illegal move rejection, checkmate and PGN history",()=>{
  let s=fresh("chess");assert.throws(()=>move(s,"alice",{type:"move",from:"e2",to:"e5"}));
  for(const [p,from,to] of [["alice","f2","f3"],["bob","e7","e5"],["alice","g2","g4"],["bob","d8","h4"]])s=move(s,p,{type:"move",from,to});assert.equal(s.winner,"bob");assert.equal(s.data.result,"Checkmate");assert.ok(s.data.pgn.includes("Qh4#"));
});
test("Connect Four: horizontal connection ends the match",()=>{let s=fresh("connect4");for(const c of [0,0,1,1,2,2,3])s=move(s,s.turn!,{type:"move",index:c});assert.equal(s.winner,"alice");});
test("SOS: scoring a line earns a bonus turn",()=>{let s=fresh("sos");for(const [i,value] of [[0,"S"],[1,"O"],[2,"S"]] as const)s=move(s,s.turn!,{type:"move",index:i,value});assert.equal(s.scores.alice,1);assert.equal(s.turn,"alice");});
test("Dots: completing a box scores and keeps the turn",()=>{let s=fresh("dots");for(const i of [0,12,3,13])s=move(s,s.turn!,{type:"move",index:i});assert.equal(s.scores.bob,1);assert.equal(s.turn,"bob");while(s.status==="playing")s=move(s,s.turn!,{type:"move",index:s.data.edges.findIndex((v:number)=>!v)});assert.equal(Object.values(s.scores).reduce((a,b)=>a+b,0),9);});
test("Bingo: shared draws, private bag and a guaranteed ending",()=>{let s=fresh("bingo");assert.equal(publicState(s,"alice").data.bag,undefined);while(s.status==="playing")s=move(s,s.turn!,{type:"draw"});assert.ok(s.winner);assert.ok(s.data.drawn.length<=25);assert.equal(new Set(s.data.drawn).size,s.data.drawn.length);});
test("RPS: secret choices, duplicate rejection and first to three",()=>{let s=fresh("rps");for(let round=0;round<3;round++){const time=NOW+round*1300+10;s=move(s,"alice",{type:"choice",value:"rock"},time);assert.equal(publicState(s,"bob").data.choices.alice,undefined);assert.equal(publicState(s,"alice").data.choices.alice,"rock");assert.throws(()=>move(s,"alice",{type:"choice",value:"paper"},time),/locked/);s=move(s,"bob",{type:"choice",value:"scissors"},time);}assert.equal(s.winner,"alice");assert.equal(s.scores.alice,3);});
test("Hangman: hidden word is not transmitted and solving wins",()=>{let s=fresh("hangman");const word=s.data.word;assert.equal(publicState(s,"bob").data.word,undefined);for(const l of new Set<string>(word.split("")))s=move(s,"alice",{type:"letter",value:l});assert.equal(s.winner,"alice");assert.equal(publicState(s,"bob").data.revealedAnswer,word);});
test("Memory: hidden pairs, mismatch lock, delayed turn, all pair scoring",()=>{let s=fresh("memory");assert.ok(publicState(s,"alice").data.cards.every((v:number)=>v===-1));const a=0,b=s.data.cards.findIndex((v:number)=>v!==s.data.cards[a]);s=move(s,"alice",{type:"move",index:a});s=move(s,"alice",{type:"move",index:b});assert.throws(()=>move(s,"alice",{type:"move",index:15}),/face-down/);s=tickGame(s,NOW+1200);assert.equal(s.turn,"bob");assert.deepEqual(s.data.revealed,[]);s=fresh("memory");for(let n=0;n<8;n++)for(const i of s.data.cards.map((v:number,i:number)=>v===n?i:-1).filter((i:number)=>i>=0))s=move(s,"alice",{type:"move",index:i});assert.equal(s.scores.alice,8);assert.equal(s.winner,"alice");});
test("Blocks: scores come from placed cells, overlapping pieces rejected",()=>{let s=fresh("blocks");s.data.pieces.alice=[0,0,0];s=move(s,"alice",{type:"place",index:0,piece:0});assert.equal(s.scores.alice,SHAPES[0].length);assert.throws(()=>move(s,"alice",{type:"place",index:0,piece:1}),/fit/);});
test("Snake: reverse rejected, directions are server-ticked",()=>{let s=fresh("snake");assert.throws(()=>move(s,"alice",{type:"direction",direction:"left"}),/reverse/);s=move(s,"alice",{type:"direction",direction:"up"});assert.equal(s.data.snakes.alice[0],65);s=tickGame(s,NOW+300);assert.equal(s.data.snakes.alice[0],53);assert.equal(s.data.snakes.bob[0],66);});
test("2048: merges happen once per move with correct scores",()=>{const b=[2,2,2,2,...Array(12).fill(0)],r=slide2048(b,"left");assert.deepEqual(r.board.slice(0,4),[4,4,0,0]);assert.equal(r.score,8);assert.deepEqual(b.slice(0,4),[2,2,2,2]);});
test("Mines: first corner is safe, mines stay hidden, clear wins",()=>{let s=fresh("mines");assert.ok(!s.data.mines.includes(0));assert.equal(publicState(s,"alice").data.mines,undefined);assert.ok(publicState(s,"alice").data.mineCells.every((v:null)=>v===null));s=move(s,"alice",{type:"reveal",index:0});for(let i=0;i<36&&s.status==="playing";i++)if(!s.data.mines.includes(i)&&!s.data.revealed.alice[i])s=move(s,"alice",{type:"reveal",index:i});assert.equal(s.winner,"alice");assert.equal(s.scores.alice,30);});
test("Sudoku: solution hidden, wrong values penalized, completion wins",()=>{let s=fresh("sudoku");assert.equal(publicState(s,"bob").data.solution,undefined);const i=s.data.givens.findIndex((n:number)=>!n),wrong=s.data.solution[i]%9+1;s=move(s,"alice",{type:"number",index:i,value:wrong});assert.equal(s.data.mistakes.alice,1);assert.equal(s.data.boards.alice[i],0);for(let j=0;j<81;j++)if(!s.data.givens[j])s=move(s,"alice",{type:"number",index:j,value:s.data.solution[j]});assert.equal(s.winner,"alice");assert.ok(s.data.boards.alice.every(Boolean));});
test("Number Guess: shared narrowing and authoritative target",()=>{let s=fresh("number");s.data.target=50;assert.equal(publicState(s,"bob").data.target,undefined);s=move(s,"alice",{type:"guess",value:40});assert.equal(s.data.low,41);s=move(s,"bob",{type:"guess",value:60});assert.equal(s.data.high,59);assert.throws(()=>move(s,"alice",{type:"guess",value:30}),/41/);s=move(s,"alice",{type:"guess",value:50});assert.equal(s.winner,"alice");});
test("Word Scramble: answer hidden and case-insensitive correct answer wins",()=>{let s=fresh("word");assert.equal(publicState(s,"bob").data.answer,undefined);s=move(s,"alice",{type:"guess",value:s.data.answer.toLowerCase()});assert.equal(s.winner,"alice");});
test("Simon: watching is enforced; complete all ten levels",()=>{let s=fresh("simon");assert.throws(()=>move(s,"alice",{type:"color",value:s.data.sequence[0]}),/Watch/);while(s.status==="playing"){const time=s.data.readyAt.alice+1,level=s.data.level.alice;for(let i=0;i<level;i++)s=move(s,"alice",{type:"color",value:s.data.sequence[i]},time);}assert.equal(s.winner,"alice");assert.equal(s.scores.alice,10);});
test("Mole: only one hit per target per player, duplicate and stale hits rejected",()=>{let s=fresh("mole");const index=s.data.mole;s=move(s,"alice",{type:"whack",index,value:0});assert.throws(()=>move(s,"alice",{type:"whack",index,value:0}),/gone/);s=move(s,"bob",{type:"whack",index,value:0});assert.equal(s.scores.alice,1);assert.equal(s.scores.bob,1);s=tickGame(s,NOW+900);assert.equal(s.data.moleRound,1);assert.throws(()=>move(s,"alice",{type:"whack",index:s.data.mole,value:0}),/gone/);});
test("Sliding: adjacent movement only and correctly ordered board wins",()=>{let s=fresh("sliding");s.data.boards.alice=[...Array.from({length:14},(_,i)=>i+1),0,15];assert.throws(()=>move(s,"alice",{type:"move",index:0}),/next/);s=move(s,"alice",{type:"move",index:15});assert.equal(s.winner,"alice");});
test("Lights: neighbor toggling and solvable finish",()=>{let s=fresh("lights");s.data.boards.alice=Array(25).fill(0);for(const i of [0,1,5])s.data.boards.alice[i]=1;s=move(s,"alice",{type:"move",index:0});assert.ok(s.data.boards.alice.every((v:number)=>v===0));assert.equal(s.winner,"alice");});
test("Timed games end on the server and offline clocks shift fairly",()=>{for(const g of GAMES){const s=fresh(g.id);if(s.endsAt){assert.equal(tickGame(s,s.endsAt+1).status,"finished");const before=s.endsAt;resumeClock(s,5000);assert.equal(s.endsAt,before+5000);}}});
test("Unknown participants, out-of-range actions and unknown game rejected",()=>{assert.throws(()=>createGame("fake",P));assert.throws(()=>move(fresh("tictactoe"),"mallory",{type:"move",index:0}),/not a player/);assert.throws(()=>move(fresh("tictactoe"),"alice",{type:"move",index:99}),/valid square/);});
test("Chess: queen, rook, bishop and knight promotions are all supported",()=>{for(const piece of ["q","r","b","n"]){const s=fresh("chess");s.data.pgn='[SetUp "1"]\n[FEN "7k/P7/8/8/8/8/8/7K w - - 0 1"]\n\n*';const next=move(s,"alice",{type:"move",from:"a7",to:"a8",value:piece});assert.equal(next.data.board[0],"w"+piece);}});
