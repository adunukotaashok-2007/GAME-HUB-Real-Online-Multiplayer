import type { NextConfig } from "next";
const nextConfig: NextConfig = {
  skipTrailingSlashRedirect: true,
  serverExternalPackages: ["socket.io", "express", "tsx", "chess.js", "pg"],
  async rewrites() {
    return [{ source: "/hub-socket/:path*", destination: `http://127.0.0.1:${process.env.REALTIME_PORT || 3001}/socket.io/:path*` }];
  },
};
export default nextConfig;
