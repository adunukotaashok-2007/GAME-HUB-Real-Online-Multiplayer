# GAMEHUB — Good games. Great company.

A complete, responsive 20-game hub with **real cross-device online multiplayer**, solo practice, private rooms, chat, reconnects, and PostgreSQL match history. The frontend and Socket.IO backend are served from **one public HTTPS URL** on Render. There are no simulated online opponents. Only solo practice uses a clearly labeled Practice Bot, where appropriate.

> The supplied repository contained a Next.js starter, not an existing 20-game implementation. All 20 requested games are implemented in this source tree. Physical phones and a Render account are not accessible from the development sandbox; follow the physical-device checklist below before announcing a public launch. Automated independent-client tests are included, but are not a claim of physical-device testing.

## Stack and source map

- Node.js 22+, Express, Socket.IO 4, Next.js App Router, React, TypeScript.
- PostgreSQL through Drizzle ORM. All gameplay moves, scoring, timers and wins are validated on the server.
- `server.js`: Express + Socket.IO production entrypoint and authoritative room manager.
- `src/lib/game-engine.ts`: all 20 rulesets, hidden-state filtering, timers and practice bots.
- `src/lib/catalog.ts`: game names, categories and instructions.
- `src/lib/use-hub.ts`: real Socket.IO client, persistent private device identity and reconnects.
- `src/components/`: library, lobby, chat and touch-friendly game boards.
- `src/app/globals.css`: complete responsive application stylesheet; fonts and artwork are local in `public/`.
- `src/db/schema.ts`: saved room snapshots and finished matches.
- `index.html`, `style.css`, `script.js`: compatibility entry files served by Express. **They are not a standalone static game site**; the actual application is the modular Next.js source above. Opening index.html from disk cannot provide online multiplayer.
- `package.json` and `package-lock.json`: dependencies and standard Next scripts.
- `render.yaml`: optional Render Blueprint for a single web service plus PostgreSQL.
- `tests/`: engine and independent Socket.IO client integration tests.

## Quick local setup

1. Install Node.js 22 or newer and PostgreSQL.
2. Download this project or clone your GitHub repository. Open a terminal in its root folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`. Set `DATABASE_URL` to your PostgreSQL connection URL. For local development, remove `APP_URL` or set it to your local app origin. Never commit `.env`.
5. Run `npx drizzle-kit push` to create the two gamehub tables.
6. Run `node server.js`. It starts Next.js in development mode and attaches Socket.IO to the same HTTP server.
7. Open the address printed by your hosting environment, or `http://127.0.0.1:3000` locally. Local addresses are for development **only**.

For a local production run: `npm run build`, then `NODE_ENV=production node server.js` (on Windows use your terminal's environment-variable syntax).

The existing `npm run dev` and `npm run start` scripts also work with a private Socket.IO sidecar that starts on first visit. Next proxies same-origin Socket.IO HTTP long-polling to it. This supports the managed preview without changing its startup scripts. **Use `NODE_ENV=production node server.js` on Render**, where native WebSocket upgrades are enabled and no sidecar is needed. Do not deploy this application to a static-site service or a serverless service that does not support persistent Socket.IO servers.

## Beginner-friendly GitHub upload

1. Sign in at github.com and choose **New repository**. Give it a name, such as `gamehub`. Do not add a starter README if pushing this existing folder.
2. Make sure `.env`, `node_modules`, `.next`, test artifacts, and logs are excluded by `.gitignore`.
3. In your project terminal run `git init`, `git add .`, and `git commit -m "Build multiplayer GAMEHUB"`.
4. Run `git branch -M main`.
5. Copy your repository URL from GitHub, then run `git remote add origin YOUR_REPOSITORY_URL` and `git push -u origin main`.
6. Alternatively, use GitHub Desktop: **Add existing repository**, commit the project files, then **Publish repository**. Do not upload `.env` or any secrets.

## Render deployment — recommended one-URL setup

You do not need a separate frontend deployment. One Render **Web Service** serves the Next.js frontend, Express backend, Socket.IO endpoint and static files. Both phones visit the same public `https://…onrender.com` website.

### A. Create PostgreSQL

1. In the Render dashboard, choose **New → Postgres**.
2. Choose a database name and region. Put the web service in the same region.
3. After creation, copy the **Internal Database URL**. Use a paid persistent database for an ongoing public deployment; check current Render pricing and free-database expiration policies.

### B. Create the website

1. Choose **New → Web Service** and connect your GitHub repository.
2. Select **Node** as runtime and your `main` branch.
3. Set **Build Command** to `npm ci --include=dev && npm run build`. Including development dependencies is intentional: TypeScript, Tailwind and Drizzle Kit are required during build and schema setup.
4. Set **Pre-Deploy Command** to `npx drizzle-kit push --force`.
5. Set **Start Command** to `NODE_ENV=production node server.js`.
6. Set **Health Check Path** to `/api/health`.
7. Choose **one instance**. A small always-on paid instance is recommended for realtime gaming. Free service sleep/cold starts interrupt rooms and add delays.
8. Add the environment variables below, then deploy. Render supplies `PORT`; do not hardcode it.

If your selected plan does not offer a pre-deploy command, use `npm ci --include=dev && npx drizzle-kit push --force && npm run build` as the build command instead. For an established production database, review schema changes and use reviewed migrations instead of blindly pushing destructive changes.

| Variable | Value |
|---|---|
| `DATABASE_URL` | Render Postgres internal connection URL |
| `NODE_ENV` | `production` |
| `NODE_VERSION` | `22` |
| `APP_URL` | Your exact public website origin, e.g. `https://your-gamehub.onrender.com` |
| `ALLOWED_ORIGINS` | Optional extra allowed origins, comma separated; otherwise leave blank |
| `NEXT_PUBLIC_SOCKET_URL` | **Leave blank** for the one-URL deployment |

Once Render assigns the website URL, set `APP_URL` to that exact HTTPS origin and redeploy. For a custom domain, add that origin to `APP_URL` or `ALLOWED_ORIGINS`. `RENDER_EXTERNAL_URL` is recognized automatically. No production client connection uses localhost: the Socket.IO client connects to the current public website origin by default. HTTPS automatically selects secure WebSockets. The private loopback URL in Next's proxy is internal server plumbing, not a phone connection URL.

### C. Optional Blueprint deployment

Choose **New → Blueprint**, connect the repository, and use `render.yaml`. It provisions the web service and database together. Set `APP_URL` to the public URL when prompted. Plans in the Blueprint are paid; confirm current pricing before applying. Keep `numInstances: 1`.

### D. Confirm deployment

Visit `https://YOUR_SITE/api/health` and check for `{ "ok": true }`. Visit the homepage and wait for **Multiplayer online**. In browser developer tools, a Render deployment should show a Socket.IO connection upgrading to `websocket`. HTTP long-polling remains a valid realtime fallback when a network blocks WebSockets. Both transports communicate with the actual server.

## Play with two actual phones

Use the public HTTPS website, **not** a LAN IP, a local file, or a loopback address.

1. **Phone A**: open the public site, choose a player name/avatar, click **Create a room**. Write down the generated 6-character code.
2. **Phone B**: use another physical phone. Turn off Wi-Fi and use mobile data (or a different Wi-Fi network). Open the same public site, choose a different name/avatar, click **Join with code**, enter A's code. An invitation link also works.
3. Confirm both phones show the same two players, code and connection statuses.
4. A chooses **Tic-Tac-Toe** in the lobby. Confirm B's selection changes immediately. B clicks **I'm ready**. Only A can start.
5. Take alternating moves. Check that boards, turns and scores agree on both screens. Try tapping during the other player's turn: it must not create a move.
6. Send typed chat, a quick message and an emoji. Confirm each arrives on the other phone.
7. Put B briefly in airplane mode. Allow about 15 seconds for heartbeat detection. A should see B reconnecting and the match clock paused. Turn mobile data back on. B should rejoin the same room automatically using the private identity stored on that browser/device.
8. Refresh B's page. The room and board should return. Do not clear website data; that intentionally deletes the device identity.
9. Finish the match and choose **Play again**. Both return to the lobby; B readies up and A starts a fresh board.
10. Repeat with Chess, a simultaneous game such as RPS, Snake (direction sync), Sudoku (race scoring), and then every remaining game below. Test iPhone Safari, Android Chrome, tablets and desktop browsers.
11. Test an invalid code, a full room, an illegal chess move, an occupied square, leaving mid-match, host transfer, and a returning host after a refresh.
12. Test after a Render service restart: saved rooms load from PostgreSQL, participants reconnect, and a saved running match resumes after both return.

**Testing record:** Automated tests can be run from this repository. Physical-device and public-Render testing must be performed by someone with those devices and a deployed account. No physical-device pass is implied by a successful local build.

## The 20 games

| Game | Online mode | Solo mode |
|---|---|---|
| Chess | Legal chess, checkmate, draw, castling, en passant, all four pawn promotions | Labeled practice bot |
| SOS | Shared 5×5 board, bonus turns, line scoring | Practice bot |
| Tic-Tac-Toe | Authoritative alternating turns | Practice bot |
| Dots & Boxes | 3×3 boxes, edge validation, bonus turns | Practice bot |
| Bingo | Independent 5×5 cards, shared number draw, first line wins | Practice bot |
| Connect Four | Shared 7×6 board and four-in-a-row | Practice bot |
| Rock Paper Scissors | Secret simultaneous choices, first to three | Practice bot |
| Hangman | Same hidden word, first solver wins, six wrong guesses | Single-player challenge |
| Memory Match | Shared hidden 16-card board, scored pairs | Practice bot |
| Block Puzzle | Separate 8×8 boards, validated placement and line clears, 2-minute score battle | Single-player timed run |
| Snake | Server-ticked separate 12×12 arenas, survival/score battle | Single-player survival |
| 2048 | Server-computed merges/spawns, 2-minute battle | Single-player timed run |
| Minesweeper | Identical 6×6 fields with six mines, first to clear | Single-player challenge |
| Sudoku | Identical standard 9×9 puzzle, correct-entry scoring, 5-minute race | Single-player timed run |
| Number Guess | Shared hidden target/range, alternating guesses | Practice bot |
| Word Scramble | Identical scramble, first correct answer | Single-player challenge |
| Simon Says | Same sequence, ten levels, three lives | Single-player memory run |
| Whack-a-Mole | Same server-timed targets, one hit per target/player, 45 seconds | Single-player score run |
| Sliding Puzzle | Identical solvable 15-puzzle, first solved | Single-player challenge |
| Lights Out | Identical solvable 5×5 boards, first dark board wins | Single-player challenge |

Timed battles compare server-verified scores at the deadline; equal scores draw. Race completion wins immediately. Solo games never add a fake online player. Solo bot chess is intended as casual practice, not a strong chess AI.

## How real multiplayer works

- A crypto-random six-character room code is checked for uniqueness in PostgreSQL.
- Each browser creates a private random token. Only its SHA-256-derived player ID is shared with peers. The token is not in invite links or room snapshots.
- Host-only selection/start, two slots, ready checks, per-turn revision checks, and synchronous server-side state transitions prevent overlapping turn commits.
- Clients send **actions**, never trusted scores or full board replacements. Invalid moves are rejected by the authoritative engine.
- Each player receives a filtered snapshot: no secret RPS choice, hidden card identity, mine locations, Sudoku solution or word answer is sent during play.
- Socket.IO heartbeats detect disconnects; room slots are reserved for 24 hours. Matches pause while any participant is offline, and their clocks resume fairly after everyone returns.
- Reconnecting or refreshing restores the same room using the private device identity. Clearing storage, changing browsers, or using private/incognito mode creates a different identity and cannot take over a reserved seat.
- Room snapshots are queued to PostgreSQL, moves are saved, high-frequency game ticks are checkpointed roughly once per second, and completed matches are saved idempotently. A hard crash can lose the last second of Snake/mole ticks; normal reconnects do not roll back gameplay.
- Chat is scoped to the room, length-limited, rate-limited, rendered as escaped text, and retained with the room snapshot.
- Favorites and recent game shortcuts are device preferences; completed match history is stored in PostgreSQL.

## Scaling and security boundaries

This implementation is designed for **one Node service instance**, not multiple independent authoritative processes. Do not enable Render horizontal autoscaling yet. Multi-instance scaling requires a shared Socket.IO adapter, shared sessions, distributed room ownership/locking and sticky polling routing; PostgreSQL snapshots alone are not a live multi-instance coordinator.

A bearer token is a guest identity, not a password-protected account. Sharing your invite is safe; sharing browser storage is not. HTTPS is required publicly. Rate limits and message limits are included. Serious ranked/prize competition should add authenticated accounts, abuse controls, stronger anti-bot validation and monitoring. The game engine prevents client-submitted score cheating, but cannot prevent a player from using external puzzle solvers or inspecting a visible memory sequence.

Room snapshots contain game secrets on the server. Never expose the room table through a public database API. Expired rooms are pruned periodically; match history is retained. Review retention before a large public launch. Connection origins should be explicitly configured in production.

## Automated tests and validation

With dependencies installed and the database schema applied:

- `npx tsx --test tests/engine.test.ts` — all 20 engines initialize and accept valid actions; illegal turns, scoring, hidden-state filtering, deterministic races, timed endings and full rules are exercised.
- `node --test tests/multiplayer.test.js` — launches temporary real Express/Socket.IO servers with PostgreSQL. Independent clients test all 20 online game engines, create/join, selection, readiness, moves/chat, illegal turns, a third-player rejection, reconnects, completed matches and rematches. Both WebSocket and polling transports are exercised. A fresh-server test verifies that PostgreSQL restores an existing board and turn.
- `node tests/public-smoke.js https://YOUR_PUBLIC_SITE` — two independent internet clients against your deployed service (not a replacement for the physical-phone checklist).
- `npx playwright install --with-deps chromium`, then `node tests/browser-smoke.js` — real desktop and mobile-size browser contexts exercise search, filters, favorites, rooms, moves, chat, refresh recovery and rematches. Set `TEST_URL` to test another deployment. Mobile emulation is not physical-phone testing.
- `node tests/browser-games.js` — opens all 20 server-created solo games in isolated mobile-size browser contexts, checks board cells, runtime errors and horizontal overflow, then leaves each room.
- `npx next typegen`
- `npm exec tsc -- --noEmit --pretty false`
- `npm run build`

The temporary test server closes when the suite ends. Integration tests create guest sessions/rooms and clean up their room snapshots.

## Troubleshooting

- **Connecting forever:** confirm Render uses `node server.js`, the schema exists, `DATABASE_URL` is correct, and `/api/health` succeeds. Check Render logs. Use a Web Service, not Static Site.
- **Works on one browser only:** both devices must use the same public HTTPS URL. Mobile phones cannot reach your computer's loopback address. Do not open `index.html` from disk.
- **CORS/origin errors:** set `APP_URL` exactly, including `https://`, with no path; add custom domains to `ALLOWED_ORIGINS`. Redeploy.
- **Room full after clearing data:** the old guest seat is still reserved. Ask the remaining player to leave and create a new room. Do not distribute private session tokens.
- **Phone locks/switches apps:** mobile operating systems suspend sockets. Return to the page; automatic reconnect restores the saved seat. Do not clear storage.
- **Free tier wakes slowly:** wait for the service to wake, or choose an always-on plan. Cold starts are not simulated gameplay.
- **Cannot write database / health fails:** verify Postgres credentials and region, then apply `npx drizzle-kit push`.

## Attribution

Interface uses Lucide icons, locally bundled Manrope font (SIL Open Font License), chess.js for legal chess rules, and original generated hero artwork. See the corresponding dependency licenses. No external game API keys are required.
